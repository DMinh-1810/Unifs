/**
 * UniFs FLM Exporter - Content Script (v1.2.0)
 * Chạy trên https://flm.fpt.edu.vn/gui/* sau khi NGƯỜI DÙNG đã tự mở trang và tự qua bước xác minh.
 * Chỉ đọc DOM của trang đang hiển thị khi người dùng bấm nút; không tự gửi request tới FLM, không tự điều hướng.
 *  - Trang Syllabus Details: lưu cả môn (thông tin chung, tài liệu, CLO, lịch học, câu hỏi, đánh giá) theo MÃ MÔN.
 *  - Trang bảng khác (vd AllCorollarySubject): lưu bảng chính theo tên trang.
 * Lưu vào data/flm_data.json qua server local (python server.py / streamlit); nếu server không chạy thì tải file JSON.
 */
(function () {
  "use strict";

  const BASE = "http://localhost:8000/api/v1/";
  const clean = (t) => (t || "").replace(/\s+/g, " ").trim();
  // Giữ xuống dòng giữa các đoạn trong một ô (vd lịch kiểm tra Test 1 / Test 2)
  const multi = (el, sep) => (el.innerText || "").split(/\n+/).map((s) => s.trim()).filter(Boolean).join(sep);
  const norm = (s) => clean(s).toLowerCase();

  /* ---------- đọc bảng ---------- */
  function readTable(table, sep) {
    const trs = Array.from(table.querySelectorAll("tr"));
    if (trs.length < 2) return null;
    let hi = trs.findIndex((tr) => tr.querySelector("th"));
    if (hi === -1) hi = 0;
    const headers = Array.from(trs[hi].children).map((c, i) => clean(c.innerText) || "col" + (i + 1));
    const rows = [];
    trs.slice(hi + 1).forEach((tr) => {
      const cells = Array.from(tr.children).map((c) => multi(c, sep || " "));
      if (!cells.length || cells.every((c) => !c)) return;
      const obj = {};
      headers.forEach((h, i) => { obj[h] = cells[i] !== undefined ? cells[i] : ""; });
      rows.push(obj);
    });
    return rows.length ? { headers, rows } : null;
  }

  function allTables() {
    return Array.from(document.querySelectorAll("table")).map((t) => ({ el: t, data: readTable(t, " / ") })).filter((x) => x.data);
  }

  /* ---------- bảng thông tin dạng "Nhãn: giá trị" ---------- */
  function readInfo() {
    const info = {};
    document.querySelectorAll("table").forEach((table) => {
      table.querySelectorAll("tr").forEach((tr) => {
        const cells = Array.from(tr.children);
        if (cells.length !== 2) return;
        const label = clean(cells[0].innerText);
        if (!/:$/.test(label)) return;
        const key = label.replace(/:$/, "").trim();
        const val = multi(cells[1], "\n");
        if (key && !(key in info)) info[key] = val;
      });
    });
    return info;
  }

  function findCol(headers, ...needles) {
    return headers.find((h) => needles.every((n) => norm(h).includes(n)));
  }

  function classify(tables) {
    const out = {};
    tables.forEach(({ data }) => {
      const h = data.headers.map(norm).join("|");
      if (h.includes("material description")) out.materials = data;
      else if (h.includes("clo name")) out.clos = data;
      else if (h.includes("session") && h.includes("topic")) out.schedule = data;
      else if (h.includes("session no") && h.includes("details")) out.questions = data;
      else if (h.includes("category") && h.includes("weight")) out.assessments = data;
    });
    return out;
  }

  /* ---------- gói dữ liệu ---------- */
  function buildSyllabus() {
    const info = readInfo();
    const code = (info["Subject Code"] || "").trim();
    if (!code) return null;
    const parts = classify(allTables());
    return {
      subject_code: code,
      source_url: location.href,
      exported_at: new Date().toISOString(),
      info,
      materials: parts.materials ? parts.materials.rows : [],
      clos: parts.clos ? parts.clos.rows : [],
      schedule: parts.schedule ? parts.schedule.rows : [],
      questions: parts.questions ? parts.questions.rows : [],
      assessments: parts.assessments ? parts.assessments.rows : [],
    };
  }

  function buildGenericTable() {
    const tables = allTables();
    if (!tables.length) return null;
    const main = tables.reduce((a, b) => (b.data.rows.length > a.data.rows.length ? b : a)).data;
    const slug = (location.pathname.split("/").filter(Boolean).pop() || "flm").replace(/[^A-Za-z0-9_-]/g, "");
    return { page: slug, source_url: location.href, exported_at: new Date().toISOString(),
             headers: main.headers, rows: main.rows, _tables: tables.length };
  }

  /* ---------- lưu / tải ---------- */
  function download(name, text) {
    const blob = new Blob(["﻿" + text], { type: "application/json;charset=utf-8" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = name;
    document.body.appendChild(a);
    a.click();
    setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 500);
  }

  function post(endpoint, payload) {
    return fetch(BASE + endpoint, { method: "POST", headers: { "Content-Type": "application/json" },
                                    body: JSON.stringify(payload) })
      .then((r) => r.json().then((j) => ({ ok: r.ok, j })))
      .then(({ ok, j }) => { if (!ok) throw new Error(j.message || "server từ chối"); return j; });
  }

  function run(statusEl) {
    const syl = buildSyllabus();
    if (syl) {
      const desc = `${syl.subject_code}: ${syl.assessments.length} đánh giá, ${syl.clos.length} CLO, ` +
                   `${syl.schedule.length} buổi, ${syl.questions.length} câu hỏi, ${syl.materials.length} tài liệu`;
      if (!syl.assessments.length) {
        statusEl.textContent = "Chưa thấy bảng Assessment. Hãy cuộn hết trang cho dữ liệu tải đủ rồi bấm lại. (" + desc + ")";
        return;
      }
      post("save-flm-syllabus", syl)
        .then((j) => { statusEl.textContent = `Đã lưu ${desc}${j.replaced ? " (cập nhật bản cũ)" : ""}. Trong file hiện có ${j.subjects_in_file} môn.`; })
        .catch((e) => {
          download(`syllabus_${syl.subject_code}.json`, JSON.stringify(syl, null, 2));
          statusEl.textContent = `Không lưu được vào server (${e.message}); đã tải file về máy: ${desc}. Hãy chạy "python server.py" rồi thử lại.`;
        });
      return;
    }
    const gen = buildGenericTable();
    if (!gen) {
      statusEl.textContent = "Chưa thấy bảng nào. Hãy qua bước xác minh và chờ bảng hiện ra rồi bấm lại.";
      return;
    }
    const info = `${gen.rows.length} dòng, ${gen.headers.length} cột (${gen._tables} bảng trên trang)`;
    delete gen._tables;
    post("save-flm-data", gen)
      .then((j) => { statusEl.textContent = `Đã lưu ${info} vào data/${j.file}${j.replaced ? " (ghi đè bản cũ của trang này)" : ""}.`; })
      .catch((e) => {
        download(`flm_${gen.page}.json`, JSON.stringify(gen, null, 2));
        statusEl.textContent = `Không lưu được vào server (${e.message}); đã tải về máy: ${info}.`;
      });
  }

  function inject() {
    if (document.getElementById("unifs-flm-box")) return;
    const box = document.createElement("div");
    box.id = "unifs-flm-box";
    box.style.cssText = "position:fixed;right:16px;bottom:16px;z-index:2147483647;font:14px system-ui,sans-serif;" +
      "display:flex;flex-direction:column;align-items:flex-end;gap:6px";
    const status = document.createElement("div");
    status.style.cssText = "max-width:320px;background:#fff;color:#222;border:1px solid #ccc;border-radius:8px;padding:6px 10px;display:none";
    const btn = document.createElement("button");
    btn.textContent = "Lưu bảng FLM vào dự án";
    btn.style.cssText = "background:#f26f21;color:#fff;border:0;border-radius:8px;padding:10px 14px;font-weight:600;cursor:pointer;box-shadow:0 2px 8px rgba(0,0,0,.25)";
    btn.addEventListener("click", () => {
      status.style.display = "block";
      status.textContent = "Đang đọc trang...";
      try { run(status); } catch (e) { status.textContent = "Lỗi: " + e.message; }
    });
    box.appendChild(status);
    box.appendChild(btn);
    document.body.appendChild(box);
  }

  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", inject);
  else inject();
})();
